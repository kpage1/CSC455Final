<?php require './includes/header.php'; ?>

<p>This tab will use the database to bring in
all current rosters from the NBA teams DB that we
have created</p>

<?php require './includes/footer.php'; ?>
