<?php require './includes/header.php'; ?>
<form action="#" method="post">
    <p>Name:</p>
    <p><input type="text" name="nm"/></p>
    <p><input type="submit" value="submit"/></p>
</form>

<?php require './includes/footer.php'; ?>