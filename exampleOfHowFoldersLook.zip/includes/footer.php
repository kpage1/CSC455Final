<footer>
  <section>Posted by: Krista Page, Alejandra O'Malley, Shaik Aziz</section>
  <section>CSC 455 Final Project: Spring 2020</section>
</footer>
</body>
</html>