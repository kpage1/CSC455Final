<?php require './includes/header.php'; ?>

 <h1>Welcome to the NBA Store</h1>
    <h4>The purpose of this site is to
    allow users to look at current NBA Rosters,
    see players game data over the past season, buy NBA merchandise,
    and become a part of our membership club.</h4>

    <p>Use the Navigation Bar to access information to players, teams,
    specific game data, to buy merchandise, or to become a part of our
    membership club. </p>


<?php require './includes/footer.php'; ?>


