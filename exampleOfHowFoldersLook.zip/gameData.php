<?php require './includes/header.php'; ?>

<p>This tab will show the data from any specific game this season
    (Since Covid-19 stopped this season abruptley, we may use data from the 2019 season</p>

<?php require './includes/footer.php';?>